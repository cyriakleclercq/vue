<template>
  <div>
    <h2>Page 3</h2>
  </div>
</template>

<script>
export default {
  name: "Page3",
};
</script>

<style></style>
