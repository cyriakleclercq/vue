<template>
  <div>
    <h2>Page 1</h2>
  </div>
</template>

<script>
export default {
  name: "Page1",
};
</script>

<style></style>
